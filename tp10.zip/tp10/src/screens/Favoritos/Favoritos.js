import React from 'react';
import { useContext } from "react";
import UserContext from '../../context/Context.js';
import '../Favoritos/Favoritos.css';
import CadaCreacion from '../../components/CadaCreacion.js';

const Favoritos = () => {
    
    const { listaFavoritos } = useContext(UserContext);
    
    return (
        <>
            <div className='containerCarritoFavs'>
                {listaFavoritos.map((c) => (
                    <CadaCreacion key={c.id} creacion={c}></CadaCreacion>
                ))}
            </div>
        </>
    );
}

export default Favoritos;
