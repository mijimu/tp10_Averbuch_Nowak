import React, { Children } from "react";
import { useState, createContext } from "react";


const UserContext = createContext();

function MainContext ( {Children} ) {
    const [listaFavoritos, setListaFavoritos] = useState([]);
    const [listaCreaciones, setlistaCreaciones] = useState([]); 


    
    return (
        <UserContext.Provider value={{listaFavoritos, listaCreaciones, setListaFavoritos, setlistaCreaciones}}>
        {Children}
        </UserContext.Provider>
        
    )

}

export default MainContext;